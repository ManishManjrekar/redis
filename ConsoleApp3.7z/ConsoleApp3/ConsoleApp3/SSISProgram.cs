﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.VSTAHosting;

namespace ConsoleApp3
{
    class SSISProgram
    {
        public static void Main(string []args)
        {

            Application app = new Application();
            Package package = null;
            //Load the SSIS Package which will be executed
            package = app.LoadPackage("Package.dtsx", null);
            
            Microsoft.SqlServer.Dts.Runtime.DTSExecResult results = package.Execute();
            foreach (var item in package.Executables)
            {
                var taskHost =(Microsoft.SqlServer.Dts.Runtime.TaskHost)item;
                if (taskHost.InnerObject != null)//
                {
                  var mybool =  taskHost.InnerObject is Microsoft.SqlServer.Dts.Tasks.ScriptTask.ScriptTask;
                    Object objx = new Object();
                    Microsoft.SqlServer.VSTAHosting.VSTAScriptProjectStorage.VSTAScriptFile scriptFileData;
                    string strFile = string.Empty;
                    if (mybool)
                    {
                        var scriptTasks = (Microsoft.SqlServer.Dts.Tasks.ScriptTask.ScriptTask)taskHost.InnerObject;
                        var files = scriptTasks.ScriptStorage.ScriptFiles;
                        string newContent = string.Empty;
                        foreach (var file in files)
                        {
                            var dict = (System.Collections.DictionaryEntry)file;
                            //var fileDetails = (Microsoft.SqlServer.VSTAHosting.VSTAScriptProjectStorage.VSTAScriptFile)file;
                            if (dict.Key.ToString().Contains("ScriptMain.cs"))
                            {
                                 scriptFileData =(Microsoft.SqlServer.VSTAHosting.VSTAScriptProjectStorage.VSTAScriptFile) dict.Value;
                               
                                 strFile = scriptFileData.Data;
                                var result = strFile.Split(new[] { "\r\n", "\r", "\n" },
                                          true ? StringSplitOptions.RemoveEmptyEntries : StringSplitOptions.None);

                                //read line by line......
                                for (int i = 0; i < result.Length; i++)
                                {
                                   
                                    if (result[i].Contains("\\") || result.Contains("c:"))
                                    {
                                        var lines = result[i].Split('=');
                                        result[i] = result[i].Replace("//" + result[i],  lines[0] + "_rams_");

                                        Console.WriteLine(result[i]);
                                        result[i] = lines[0] + "=_rams_;";

                                        Console.WriteLine();
                                    }
                                    newContent += result[i];
                                }
                                Console.WriteLine(newContent);
                                dict.Value = (object)newContent;
                                dict.Value = new VSTAScriptProjectStorage.VSTAScriptFile(VSTAScriptProjectStorage.Encoding.UTF8, newContent);
                                // 8. Reload the script project, build and save

                                //package.ScriptingEngine.LoadProjectFromStorage();
                                //task.ScriptingEngine.VstaHelper.Build("");

                                //// 9. Persist the VSTA project + binary to the task
                                //if (!task.ScriptingEngine.SaveProjectToStorage())
                                //{
                                //    throw new Exception("Save failed");
                                //}

                                //// 10. Cleanup
                                //task.ScriptingEngine.DisposeVstaHelper();

                            }




                        }

                        Console.WriteLine();
                    }
                }
                Console.WriteLine();

            }
            Console.WriteLine();
            var newFileName = string.Empty;
            //package.Variables.Add("");
            //package.sa
            package.SaveToXML(out newFileName, null);
            System.IO.File.WriteAllText(@"D:\Practice\rams.dtsx", newFileName);
        }
    }
}
