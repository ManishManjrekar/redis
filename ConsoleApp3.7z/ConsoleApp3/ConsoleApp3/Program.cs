﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using static ConsoleApp3.Worker;

namespace ConsoleApp3
{
    //class Program
    //{
    //    //public delegate void MyGenericDelWorkHandler(object sender, WorkPerformedEventArgs args);
    //    static void Main(string[] args)
    //    {

           

    //        //Worker myMathClass = new Worker();
    //        //MyDelWorkHandler objdelgate = new MyDelWorkHandler(myMathClass.DoAddtionWork);
    //        //objdelgate(7, 7);

    //        int hour = 6;
    //        WorkType friendly = WorkType.Golf;

    //        Worker worker = new Worker();
    //        worker.WorkPerformed += new MyGenericDelWorkHandler(work_WorkPerformed);
    //        worker.DoWork(hour, friendly);
    //        worker.WorkCompleted += Worker_WorkCompleted;
          


    //        Worker TwitterWorker = new Worker();
    //        TwitterWorker.WorkPerformed += new MyGenericDelWorkHandler(Twitterwork_WorkPerformed);
    //        TwitterWorker.DoWork(hour, friendly);
    //        TwitterWorker.WorkCompleted += Worker_WorkCompleted;

    //        Console.WriteLine();
    //    }

    //    private static void Worker_WorkCompleted(object sender, EventArgs e)
    //    {
    //        Console.WriteLine($"Work completed.....");
    //    }

    //    static void work_WorkPerformed(object sender, WorkPerformedEventArgs args)
    //    {
    //        Console.WriteLine($"Hours worked are :- " + args.Hours);
    //    }

    //    private static void TwitterWorker_WorkCompleted(object sender, EventArgs e)
    //    {
    //        Console.WriteLine($"Twitter Worker Work completed.....");
    //    }

    //    static void Twitterwork_WorkPerformed(object sender, WorkPerformedEventArgs args)
    //    {
    //        Console.WriteLine($"TwitterWorker Hours worked are :- " + args.Hours);
    //    }
    //}
    //public enum WorkType
    //{
    //    GoToMeetings,
    //    Golf,
    //    Coding
    //}
    //public class Worker
    //{
    //    public delegate void MyDelWorkHandler(int i, int j);
    //    public delegate void MyGenericDelWorkHandler(object sender, WorkPerformedEventArgs args);

    //    public event MyGenericDelWorkHandler WorkPerformed;
    //    public event EventHandler WorkCompleted;

    //    public virtual void DoWork(int hours, WorkType worktype)
    //    {
    //        for (int k = 0; k < hours; k++)
    //        {
    //            //Work started.....
    //            System.Threading.Thread.Sleep(1000);
    //            OnWorkPerformed(k + 1, worktype);
    //        }
    //        // Work completed now....
    //        OnWorkCompleted();
    //    }

    //    public virtual void OnWorkPerformed(int hours, WorkType worktype)
    //    {

    //        //MyDelWorkHandler del = WorkPerformed as MyDelWorkHandler;
    //        var del = WorkPerformed as MyGenericDelWorkHandler;

    //        if (del != null)
    //        {
    //            del(this, new WorkPerformedEventArgs(hours, worktype));
    //        }
    //    }
    //    public virtual void OnWorkCompleted()
    //    {

    //        var del = WorkCompleted as EventHandler;
    //        if (del != null)
    //        {
    //            del(this, EventArgs.Empty);
    //        }
    //    }
    //    public void DoAddtionWork(int i, int j)
    //    {
    //        Console.WriteLine("Addition of numbers work going on...");
    //    }
    //}
}
